# 电池 EIS REV A — BE03 低频采集与研究模型接口

当前源码为 **BE03**：固定最终装配 R1=10Ω/5W、R2=0.100Ω、R5=2.49kΩ、电压还原系数1.249。默认双频 **2.16 / 17.8 Hz，各重复两次**。原 BE01/BE02 发布包和制造文件保留。

最新离线补丁见 [软件验证与数据追溯记录](docs/be03_ps_validation_20261022.md)，证据在 `reports/prepcb_continue_20261022-201335/`。原BE03构建记录保留于 [BE03 工作记录](docs/be03_lowfreq_model.md)。新 PCB 尚未到货；只在板上隔离目录做过软件测试，未加载位流、操作ADC/DAC或改变原服务/网络，现按用户要求保持离线。数字验证不能代替实物验收。

## 本版能力

- PL 继续完成单极方波负载控制、ADS1256 两路差分交替采样、真实 DRDY 时间戳、18 项锁相累积与保护。
- 候选采集范围扩为 **2–100 Hz**，每窗最长4秒，原始 RAM 为16384条；原4096条地址升级为14位，状态 ABI 改为BE03。驱动拒绝旧位流，且核对固件能力页。
- 软件按实际 DDS 频率分配至少8周期；低于10Hz时稳定时间至少1周期。这只是待实测的时间安排，不能证明电化学过程已稳定。
- 默认实际频率2.165324986 / 17.811544240 Hz；低频稳定0.46182445秒、采集3.69459553秒，高频稳定0.25秒、采集1秒。两次重复加0.4秒预检的窗口预算 **11.21283996秒**。
- 记录初始化、配置、等待/读回、保存、分析、推理和总耗时。默认20秒协作式软件时限，超预算停止并标记TIMEOUT；不可中断的系统调用和最后保存/显示可能额外耗时，尚不构成完整实测20秒保证。
- PS接入冻结的Ridge和32树森林便携推理，权重与研究目录逐字节一致。当前目标电池、温度及PCB域仍未验证，实际测量不输出有效SOH/RUL。PL模型计算核保持独立，未在本版连接AXI。
- 界面保留原800×600深灰/青色/蓝色卡片风格，分别显示模型载入、数据待核验、目标电池待验证和明确标记的公开数据回放。

## 接线与数据

J1：F+、S+、S−、F−；J2：AD0、AD1、AD2、AD3、DA0、AGND。电压取AD0−AD1，名义还原乘1.249；电流取AD2−AD3并除实测R2。放电为正，复阻抗为 `Z=-V_ac/I_ac`。S−/AD1与AGND相连，**AD3/F−不得另行短接AGND**。DA0关断码为0，DA1未用。

新旧程序、位流和校准不可混用。每个频点的ABI、硬件、波形、真实频率、窗口及RAM版本均进入校准binding。`config/calibration_two_frequency.template.json` 是空白模板，没有实测修正系数。ADC内部自校准和外置标准A/B核验都不能替代两通道独立传递校准。

## 不接硬件即可运行

在本目录执行，使用已安装的Python和NumPy；预览另需Pillow：

```powershell
python -B ps/app.py simulate --profile config/profile.example.json --output reports/my_simulation
python -B ps/app.py preview --output reports/my_preview
python -B scripts/validate_prepcb.py reports/my_prepcb_validation
python -B ps/app.py audit-session --session data/具体会话 --output reports/audit.json
python -B ps/app.py export-candidate --session data/具体会话 --output reports/unlabelled_candidate.json
```

`validate_prepcb.py` 要求输出目录不存在。它生成明确标记的模拟profile/参考、模拟采集及公开样本回放；这些文件不得作实物校准。未经校准的simulate保持UNVERIFIED。带模拟传递参考的流程可验证复阻抗接口，但模型仍按simulation域拒判。

公开数据样例单独回放：

```powershell
python -B ps/app.py replay-model --model models/frozen_two_frequency_20261022/lib_two_ridge.json --input models/frozen_two_frequency_20261022/lib_two_ridge.example.json --output reports/public_replay.json
```

CLI的`--model`默认选择LIB Ridge研究候选，可指定同目录KIT森林。选择模型不授权跳过域检查。未知温度/SOC不填假值；`rul`始终null。`--frequency 80`可运行单点诊断，模型会拒绝不完整双频输入。

## 仿真、测试与构建

```powershell
./scripts/simulate.ps1
./scripts/simulate_lowfreq.ps1
python -B -m unittest discover -s tests -v
./scripts/build.ps1
python -B scripts/package_release.py --build D:/cyx/nt/实际新构建目录
```

使用工程既有Vivado2025.2及xc7z020clg400-1。完整SPI测试与核心长缓存测试分开：后者使用缩放逻辑时钟和ADC桩，仅验证窗口、地址、统计、边界和溢出停止，不能冒充真实ADS1256的低频测量。

原构建包 `release/be03_20261022/` 保持冻结。上述 `package_release.py` 是原构建入口，不能拿新源码覆盖旧包；本次软件补丁使用 `package_ps_patch.py`，创建全新版本目录并绑定原BE03位流。状态以各版本manifest及acceptance为准，原BE01/BE02/BE03包均保留。新构建输出采用独立短目录，不覆盖原RLC工程。

## 板到后

到货前的统一离线验收、诊断命令和待填表见 [离线交付说明](docs/offline_readiness_20261023.md)。运行 `python -B scripts/accept_offline.py --output reports/新的验收目录` 可验证整条主机软件链，并生成 `arrival_kit`。该入口只运行模拟/文件处理，不部署开发板。

按 [板端验收顺序](docs/board_acceptance.md) 核对实物、先确认零驱动与保护，再做DC/复数传递校准、低毫欧标准增量核验、实际幅相/噪声与整次耗时测量。旧RLC仍连接时不得加载电池负载程序。示例profile确认项均为false，实际阈值由电池规格与装配确定。

本轮修改前的精简SHA-256备份见 `reports/be03_lowfreq_model_20261022/snapshot.txt`；历史发布包哈希保存在同目录。回退须成套恢复源码/位流/校准，加载前断开电池。
