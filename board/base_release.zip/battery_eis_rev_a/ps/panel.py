"""800x600 panel preserving the approved graphite/cyan/blue composition.

NumPy glyph atlas keeps PIL/font discovery off the embedded runtime path.
"""
from pathlib import Path
import numpy as np
from configuration import DEFAULT_SWEEP

BG=(29,26,24);SURFACE=(48,42,36);DARK=(37,33,29);TEXT=(247,244,241)
MUTED=(204,195,184);CYAN=(232,201,72);BLUE=(255,181,123);AI=(63,43,29)
BORDER=(85,81,77);ORANGE=(88,171,255)
LABELS='电池阻抗首页扫频校准状态电压电流复相位测量进度开始取消已停止准备未接入中自检采集分析完成待核验错误超时正在清理数据保存模型未配置物理接线确认当前温度未知标准件选择单点上一下一重复次正常外置串联先停励后移动仅正极取样线位置返回端保持不动内部不等于整机标定禁止单独接无源电阻先完成再停机记录有效低信号请查看详情仿真已标定未标定外部核验幅值原始信号拒绝无寿命结果重新测量配置文件初始化未就绪传感器' 
LABELS+=' 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz.,:+-/%()=[]_°Ωμ→'
STATUS={'IDLE':'准备就绪','INITIALIZING':'初始化','PREFLIGHT':'自检中','CAPTURING':'采集中',
        'ANALYZING':'分析中','CANCELLING':'正在停止','DONE':'测量完成','UNVERIFIED':'待核验',
        'ERROR':'测量错误','TIMEOUT':'采集超时','CANCELLED':'已取消'}
BUSY={'INITIALIZING','PREFLIGHT','CAPTURING','ANALYZING','CANCELLING'}
NAV=('首页','扫频','校准','状态')

def ai_label(ai):
    ai=ai or {}
    if ai.get('status')=='research_estimate' and ai.get('soh') is not None:
        return '研究 SOH %.1f%%'%(100*ai['soh'])
    if ai.get('reason')=='awaiting_measurement':return '模型已载入'
    if ai.get('reason')=='domain_requires_validation':return '目标电池待验证'
    if ai.get('status')=='rejected':return '数据待核验'
    return '模型未配置'

class Painter:
    def __init__(self,atlas=None):
        # NpzFile indexing decompresses each glyph again, including width checks.
        # Decode once before the UI loop; pixels and all layout rules stay exact.
        with np.load(atlas or Path(__file__).resolve().parents[1]/'assets/glyphs.npz',allow_pickle=False) as archive:
            self.atlas={key:archive[key] for key in archive.files}
        self.bounds=[]

    def width(self,text,size):return sum(self.atlas['%d_%d'%(size,ord(c))].shape[1] for c in text)

    def text(self,frame,x,y,text,size=24,color=TEXT,width=750):
        text=str(text)
        # Missing user metadata chars use '?' rather than silently disappearing.
        text=''.join(c if '%d_%d'%(size,ord(c)) in self.atlas else '?' for c in text)
        while text and self.width(text,size)>width:text=text[:-1]
        self.bounds.append((x,y,x+self.width(text,size),y+size+8,text))
        for char in text:
            mask=self.atlas['%d_%d'%(size,ord(char))]
            h,w=mask.shape
            if x<0 or y<0 or x+w>800 or y+h>600:raise ValueError('text outside frame')
            alpha=mask.astype(np.uint16)[...,None]
            region=frame[y:y+h,x:x+w]
            region[:]=(region.astype(np.uint16)*(255-alpha)+np.array(color,dtype=np.uint16)*alpha+127)//255
            x+=w

    def button(self,frame,rect,label,active=False):
        x,y,x1,y1=rect;frame[y:y1,x:x1]=SURFACE if active else DARK
        frame[y:y+2,x:x1]=CYAN if active else BORDER;frame[y1-2:y1,x:x1]=CYAN if active else BORDER
        self.text(frame,x+(x1-x-self.width(label,24))//2,y+(y1-y-32)//2,label,color=CYAN if active else TEXT,width=x1-x)

    def render(self,state,page=0,selected_hz=80,sweep=False,position='normal',calibrated=False,frequencies=DEFAULT_SWEEP):
        frame=np.empty((600,800,3),dtype=np.uint8);frame[:]=BG;frame[:70]=DARK;self.bounds=[]
        self.text(frame,20,20,'电池阻抗',24,width=210)
        self.text(frame,300,22,('%g Hz'%state.get('frequency_hz',selected_hz)),24,CYAN,width=200)
        busy=state.get('status') in BUSY
        self.button(frame,(646,10,784,60),'取消' if busy else '已停止',busy)
        for index,label in enumerate(NAV):self.button(frame,(16+index*194,540,202+index*194,594),label,index==page)
        result=state.get('result')
        def value(key,fmt,factor=1):
            val=result.get(key) if result else None
            return '--' if val is None else format(val*factor,fmt)
        if page==0:
            for x,x1,label,val in [(16,392,'电池电压',value('voltage_dc_v','.4f')+' V'),
                                  (404,784,'放电电流',value('current_dc_a','.3f',1000)+' mA')]:
                frame[86:210,x:x1]=SURFACE;frame[86:87,x:x1]=BORDER
                self.text(frame,x+20,102,label,color=MUTED,width=x1-x-40)
                self.text(frame,x+20,151,val,32,CYAN,width=x1-x-40)
            self.text(frame,36,230,'|Z| '+value('magnitude_ohm','.3f',1000)+' mΩ',width=350)
            self.text(frame,424,230,'相位 '+value('phase_deg','+.2f')+'°',width=340)
            frame[296:496,16:784]=AI;frame[296:496,16:21]=BLUE
            self.text(frame,36,309,'AI 分析',32,BLUE,width=360)
            self.text(frame,36,360,ai_label(state.get('ai')),24,BLUE,width=480)
            if busy:
                self.text(frame,36,405,STATUS[state['status']],24,width=460)
                frame[452:458,36:764]=DARK
                frame[452:458,36:36+int(728*state.get('progress',0))]=BLUE
            else:
                self.text(frame,36,412,STATUS.get(state.get('status','IDLE'),'待核验'),20,width=420)
                self.button(frame,(540,430,764,482),'开始测量',True)
            if state.get('source')=='simulation':self.text(frame,250,21,'仿真',20,ORANGE,width=70)
            if state.get('source')=='public_dataset_replay':self.text(frame,250,21,'回放',20,ORANGE,width=70)
        elif page==1:
            self.text(frame,20,87,'扫频配置',24)
            frame[132:282,16:784]=SURFACE
            self.text(frame,36,150,'当前频率',24,MUTED,width=350)
            self.text(frame,36,194,'%g Hz'%selected_hz,32,CYAN,width=350)
            self.button(frame,(420,166,578,226),'上一点');self.button(frame,(600,166,764,226),'下一点')
            self.button(frame,(16,310,392,370),'单点',not sweep)
            self.button(frame,(404,310,784,370),'扫频',sweep)
            self.text(frame,36,396,' / '.join('%g'%f for f in frequencies)+' Hz',24,width=720)
            self.button(frame,(540,430,764,482),'开始测量',True)
        elif page==2:
            self.text(frame,20,87,'校准与核验',24)
            frame[132:280,16:784]=SURFACE
            self.text(frame,36,150,'校准已载入' if calibrated else '未标定',32,CYAN,width=700)
            self.text(frame,36,205,'外置标准件始终串联正极',24,width=710)
            self.text(frame,36,246,'DA0=0 后仅移动 S+',20,MUTED,width=710)
            for rect,key,label in [((16,310,260,370),'normal','正常'),((278,310,522,370),'A','位置 A'),((540,310,784,370),'B','位置 B')]:
                self.button(frame,rect,label,position==key)
            self.text(frame,36,395,'S- 保持不动',24,width=480)
            self.button(frame,(540,430,764,482),'开始测量',True)
        else:
            self.text(frame,20,87,'状态',24)
            lines=[STATUS.get(state.get('status','IDLE'),'待核验'),
                   '记录 %d / %d'%(state.get('completed',0),state.get('total',0)),
                   '校准已载入' if calibrated else '未标定',
                   state.get('error') or (' / '.join(result.get('reasons',[])) if result else '未接入'),
                   '温度 / SOC 见记录', 'AI '+ai_label(state.get('ai'))]
            for j,line in enumerate(lines):self.text(frame,36,144+j*54,line,20 if j==3 else 24,width=728,color=ORANGE if j==3 else TEXT)
        return frame

def action(point,page,busy):
    x,y=point
    if 540<=y<594 and 16<=x<784:return ('page',min(3,(x-16)//194))
    if busy:return ('cancel',None) if 646<=x<784 and 10<=y<60 else None
    if 540<=x<764 and 430<=y<482:return ('start',None)
    if page==1:
        if 420<=x<578 and 166<=y<226:return ('frequency',-1)
        if 600<=x<764 and 166<=y<226:return ('frequency',1)
        if 310<=y<370:return ('sweep',x>=404)
    if page==2 and 310<=y<370:
        return ('position','normal' if x<260 else 'A' if x<522 else 'B')
    return None
