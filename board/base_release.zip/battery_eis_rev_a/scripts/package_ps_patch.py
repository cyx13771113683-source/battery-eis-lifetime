"""Freeze a new PS-only BE03 release; never replace the original build package."""
import argparse
from datetime import datetime,timezone
import difflib
import hashlib
import json
from pathlib import Path
import re
import shutil
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'release/be03_20261022'
BASE_ARCHIVE=BASE/'battery_eis_rev_a_be03_20261022.zip'
BASE_SHA='cc17b127e5cf06ad47470c0c46796f418564311af938808c8f8a4f072fe7897e'
sys.path.insert(0,str(ROOT/'ps'))
from configuration import ABI,ASSEMBLY_SHA256

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def write(path,data):
    with path.open('x',encoding='utf-8') as stream:json.dump(data,stream,ensure_ascii=False,indent=2,allow_nan=False)

def sources():
    files=[ROOT/'README.md']
    for name in ('ps','rtl','sim','scripts','config','assets','docs','tests','models'):
        files.extend(p for p in (ROOT/name).rglob('*') if p.is_file() and '__pycache__' not in p.parts
                     and p.name not in ('finalize_timing.tcl','export_matching_xsa.tcl'))
    return {p.relative_to(ROOT).as_posix():sha(p) for p in sorted(files)}

def check_baseline():
    if sha(BASE_ARCHIVE)!=BASE_SHA:raise ValueError('original BE03 archive changed')
    baseline=read(BASE/'source_manifest.json')
    with zipfile.ZipFile(BASE_ARCHIVE) as archive:
        if archive.testzip() is not None:raise ValueError('original archive CRC failed')
        for name,expected in baseline.items():
            content=archive.read('battery_eis_rev_a/'+name)
            if hashlib.sha256(content).hexdigest()!=expected:raise ValueError('original source manifest mismatch '+name)
            if (name.startswith(('rtl/','models/','config/')) or name=='ps/configuration.py') and sha(ROOT/name)!=expected:
                raise ValueError('not a PS-only patch: hardware/model/config changed '+name)
    manifest=read(BASE/'manifest.json')
    if manifest['abi']!=ABI or manifest['assembly_sha256']!=ASSEMBLY_SHA256:
        raise ValueError('base ABI/assembly mismatch')
    for name,expected in manifest['files'].items():
        if sha(BASE/name)!=expected:raise ValueError('base FPGA file changed '+name)
    return baseline,manifest

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--report',type=Path,required=True)
    parser.add_argument('--prepare-review',action='store_true')
    parser.add_argument('--release',type=Path)
    args=parser.parse_args();report=args.report.resolve()
    if report.parent!=ROOT/'reports':raise ValueError('report must be a direct project reports child')
    baseline,manifest=check_baseline();current=sources()
    if args.prepare_review:
        snapshot=Path(read(report/'snapshot.json')['path'])
        saved=read(snapshot/'manifest.json')
        for row in saved:
            if sha(snapshot/row['path'])!=row['sha256']:raise ValueError('backup mismatch '+row['path'])
        previous=read(ROOT/'reports/be03_lowfreq_model_20261022/source_review.json')['preserved_files']
        for path,expected in previous.items():
            if sha(Path(path))!=expected:raise ValueError('historical release changed '+path)
        diffs=[]
        with zipfile.ZipFile(BASE_ARCHIVE) as archive:
            for name,expected in current.items():
                if name in baseline and expected!=baseline[name]:
                    old=archive.read('battery_eis_rev_a/'+name).decode('utf-8-sig').replace('\r\n','\n').splitlines(keepends=True)
                    new=(ROOT/name).read_text(encoding='utf-8-sig').splitlines(keepends=True)
                    diffs.extend(difflib.unified_diff(old,new,fromfile='BE03/'+name,tofile='PS_patch/'+name))
        (report/'source.diff').write_text(''.join(diffs),encoding='utf-8')
        write(report/'source_review.json',dict(backup_verified=True,snapshot=str(snapshot),
            preserved_files_match=True,preserved_files=previous,
            production_rtl_model_config_unchanged=True,original_archive_sha256=BASE_SHA,
            modified_files=[n for n,h in current.items() if n in baseline and h!=baseline[n]],
            new_files=[n for n in current if n not in baseline],current_source_sha256=current))
        print(json.dumps(dict(status='READY_FOR_MAIN_REVIEW',source_files=len(current))))
        return
    review=read(report/'source_review.json')
    if review['current_source_sha256']!=current:raise ValueError('source changed after review preparation')
    if not review['backup_verified'] or not review['preserved_files_match']:raise ValueError('preservation gate failed')
    testlog=(report/'host_tests_final.log').read_text(encoding='utf-8-sig')
    match=re.search(r'Ran (\d+) tests',testlog)
    if not match or not re.search(r'^OK\s*$',testlog,re.MULTILINE):raise ValueError('host test gate failed')
    normal=(report/'spi_contract/run.log').read_text(encoding='utf-8-sig')
    negative=(report/'spi_contract/negative_short_wait.log').read_text(encoding='utf-8-sig')
    if 'PASS_SPI_CONTRACT' not in normal or 'PASS_BATTERY_EIS' not in normal or 'FAIL_' in normal:
        raise ValueError('normal SPI contract gate failed')
    if 'Fatal: FAIL_CONTRACT_T6' not in negative or 'PASS_SPI_CONTRACT' in negative:
        raise ValueError('negative SPI control gate failed')
    ui=read(report/'ui_pixel_equivalence.json')
    if ui['pixel_identical_cases']!=44:raise ValueError('UI equivalence gate failed')
    release=args.release.resolve() if args.release else None
    if release is None or release.parent!=ROOT/'release' or release.exists():
        raise ValueError('choose a new direct release directory')
    release.mkdir()
    for name in manifest['files']:shutil.copy2(BASE/name,release/name)
    frozen=dict(manifest,schema='battery-eis-ps-release/1',created_utc=datetime.now(timezone.utc).isoformat(),
        fpga_origin_release='be03_20261022',fpga_origin_archive_sha256=BASE_SHA,
        production_rtl_unchanged=True,board_validated=False,optimized_ps_arm_validated=False)
    write(release/'manifest.json',frozen);write(release/'source_manifest.json',current)
    acceptance=dict(schema='battery-eis-ps-acceptance/1',abi=ABI,host_tests=int(match[1]),
        spi_contract_passed=True,spi_negative_control_passed=True,pixel_identical_cases=44,
        original_fpga_unchanged=True,board_validated=False,full_20s_hardware_validated=False,
        optimized_ps_arm_validated=False,arm_baseline_observation='arm_observed.json',
        assembly_sha256=ASSEMBLY_SHA256,source_files=len(current),
        pending=['retrieve original ARM evidence when connection is restored',
                 'optimized PS timing on ARM','physical PCB acceptance and calibration',
                 'independent target-cell capacity labels and held-out validation'])
    write(release/'acceptance.json',acceptance)
    archive=release/(release.name+'.zip')
    report_files=[p for p in report.rglob('*') if p.is_file()
                  and not any(part=='arm_stage' or part.startswith('package_check') or part=='__pycache__' for part in p.relative_to(report).parts)
                  and p.suffix in ('.json','.jsonl','.csv','.log','.txt','.md','.diff','.py','.png','.svg')]
    delivery=[ROOT/name for name in current]+report_files+[p for p in release.iterdir() if p.is_file()]
    prior_reports=ROOT/'reports/be03_lowfreq_model_20261022'
    for folder in ('rtl','rtl_lowfreq'):
        delivery.extend(p for p in (prior_reports/folder).iterdir() if p.is_file())
    delivery.append(prior_reports/'acceptance.json')
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as output:
        for path in sorted(set(delivery)):
            output.write(path,'battery_eis_rev_a/'+path.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(archive) as output:
        if output.testzip() is not None:raise ValueError('new archive CRC failed')
    write(release/'archive_sha256.json',dict(file=archive.name,sha256=sha(archive),bytes=archive.stat().st_size))
    print(json.dumps(dict(archive=str(archive),sha256=sha(archive),acceptance=acceptance),indent=2))

if __name__=='__main__':main()
