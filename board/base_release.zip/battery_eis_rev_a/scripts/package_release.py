"""Package a successful isolated build with source, evidence and hash binding."""
import argparse
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import sys
import zipfile
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
REPO=ROOT.parents[2]
REPORTS=ROOT/'reports/be03_lowfreq_model_20261022'
RELEASE=ROOT/'release/be03_20261022'
sys.path.insert(0,str(ROOT/'ps'))
from configuration import ABI,ASSEMBLY_ID,ASSEMBLY_SHA256,Settings,DEFAULT_SWEEP,RAW_CAPACITY

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--build',type=Path,required=True)
    args=parser.parse_args();build=args.build.resolve()
    result=(build/'reports/build_result.txt').read_text()
    fields=dict(line.split('=',1) for line in result.splitlines() if '=' in line)
    if fields.get('ABI')!='BE03' or float(fields['setup_ns'])<0 or float(fields['hold_ns'])<0:
        raise ValueError('FPGA build gate failed')
    sim=(ROOT/'build/sim/run.log').read_text(encoding='utf-8-sig')
    required=['NORMAL','CANCEL','WATCHDOG','UNDERVOLTAGE','OVERVOLTAGE','OVERCURRENT','REVERSE_CURRENT','SATURATION','ADC_TIMEOUT','ADC_ID_REJECT','BATTERY_EIS']
    if not all('PASS_'+name in sim for name in required) or 'Fatal:' in sim:
        raise ValueError('RTL simulation gate failed')
    lowlog=(ROOT/'build/sim_lowfreq/run.log').read_text(encoding='utf-8-sig')
    if not all('PASS_'+tag in lowlog for tag in ('LONG_CAPTURE','BE03_LIMITS','RAM_OVERFLOW_STOP','LOWFREQ_BUFFER')) or 'Fatal:' in lowlog:
        raise ValueError('low-frequency simulation gate failed')
    testlog=(REPORTS/'host_tests.log').read_text(encoding='utf-8-sig')
    match=re.search(r'Ran (\d+) tests',testlog)
    if not match or not re.search(r'^OK\s*$',testlog,re.MULTILINE):raise ValueError('host tests not passed')
    snapshot=Path((ROOT/'reports/baseline_snapshot.txt').read_text(encoding='utf-8-sig').strip())
    baseline=json.loads((snapshot/'manifest.json').read_text(encoding='utf-8-sig'))
    changed=[item['path'] for item in baseline if sha(REPO/item['path'])!=item['sha256'].lower()]
    if changed:raise ValueError('baseline files changed: '+repr(changed))
    authority=REPO/'personal/workspace/hardware/battery_eis_frontend/pcb_rev_a_20261020/final_assembly_log_20261021.md'
    if sha(authority)!=ASSEMBLY_SHA256 or sha(ROOT/'docs/final_assembly_log_20261021.md')!=ASSEMBLY_SHA256:
        raise ValueError('final assembly authority changed; review before packaging')
    preservation=json.loads((REPORTS/'source_review.json').read_text(encoding='utf-8'))
    if not preservation['preserved_files_match'] or not preservation['backup_verified']:
        raise ValueError('preservation review incomplete')
    if any(sha(ROOT/p)!=h for p,h in preservation['current_source_sha256'].items()):
        raise ValueError('source changed after review')
    hwh=ET.parse(build/'release/battery_eis.hwh')
    addresses={m.attrib['INSTANCE']:int(m.attrib['BASEVALUE'],16) for m in hwh.iter('MEMRANGE')}
    for name,address in dict(waveshare_config=0x81260000,left_result=0x81270000,right_result=0x81280000,waveshare_status=0x81290000).items():
        if addresses.get(name)!=address:raise ValueError('HWH address mismatch '+name)
    with zipfile.ZipFile(build/'release/battery_eis.xsa') as xsa:
        embedded=[n for n in xsa.namelist() if n.endswith('.bit')]
        if len(embedded)!=1 or hashlib.sha256(xsa.read(embedded[0])).hexdigest()!=sha(build/'release/battery_eis.bit'):
            raise ValueError('XSA embedded bitstream does not match release BIT')
    release=RELEASE;release.mkdir(parents=True,exist_ok=True)
    for name in ('battery_eis.bit','battery_eis.hwh','battery_eis.xsa'):
        target=release/name;source=build/'release'/name
        if target.exists() and sha(target)!=sha(source):
            raise ValueError('different release exists; make a versioned snapshot before replacing '+name)
        shutil.copy2(source,target)
    reports=REPORTS/'fpga';reports.mkdir(exist_ok=True)
    for path in (build/'reports').iterdir():
        if path.is_file():shutil.copy2(path,reports/path.name)
    simdir=REPORTS/'rtl';simdir.mkdir(exist_ok=True)
    for name in ('run.log','rtl_raw.csv','rtl_stats.csv'):shutil.copy2(ROOT/'build/sim'/name,simdir/name)
    lowdir=REPORTS/'rtl_lowfreq';lowdir.mkdir(exist_ok=True)
    for name in ('run.log','lowfreq_raw.csv','lowfreq_stats.csv'):shutil.copy2(ROOT/'build/sim_lowfreq'/name,lowdir/name)
    frontend=REPO/'personal/workspace/hardware/battery_eis_frontend/pcb_rev_a_20261020/design_spec.json'
    manifest=dict(schema='battery-eis-release/3',abi=ABI,frontend_sha256=sha(frontend),
        assembly_id=ASSEMBLY_ID,assembly_sha256=ASSEMBLY_SHA256,
        created_utc=datetime.now(timezone.utc).isoformat(),build_directory=str(build),
        files={path.name:sha(path) for path in release.iterdir() if path.suffix in ('.bit','.hwh','.xsa')},
        board_validated=False)
    write(release/'manifest.json',manifest)
    acceptance=dict(schema='battery-eis-acceptance/3',abi=ABI,host_tests=int(match[1]),rtl_passes=required,
        rtl_moments_independently_recomputed=18,setup_slack_ns=float(fields['setup_ns']),
        hold_slack_ns=float(fields['hold_ns']),vivado='2025.2',part=fields['part'],
        initial_setup_slack_ns=float(fields['initial_setup_ns']),
        postroute_physical_optimization=float(fields['initial_setup_ns'])<0,
        baseline_files_unchanged=len(baseline),baseline_snapshot=str(snapshot),
        assembly_id=ASSEMBLY_ID,assembly_sha256=ASSEMBLY_SHA256,
        nominal_components=dict(r1_ohm=10,r2_ohm=.1,r5_ohm=2490,voltage_restoration=1.249),
        default_frequency_hz=80,candidate_frequency_hz=[2,100],default_sweep_hz=list(DEFAULT_SWEEP),
        raw_capacity_samples=RAW_CAPACITY,maximum_capture_s=4.,
        default_window_budget_s=.4+sum(2*(Settings().for_frequency(f).capture_s+Settings().for_frequency(f).settle_s) for f in DEFAULT_SWEEP),
        adc_drate_sps=30000,adc_differential_multiplexed=True,
        prechange_snapshot=str(preservation['snapshot']),preserved_files=preservation['preserved_files'],
        board_validated=False,arm_time_seconds=None,absolute_impedance_accuracy=None,
        physical_ui_validated=False,health_model='frozen research Ridge/forest on PS; board domain rejected',
        model_pl_core_integrated=False,full_20s_hardware_validated=False,
        hwh_addresses_verified=True,xsa_bit_matches=True,inherited_peripheral_io_warnings=True,
        pending=['physical converter/pin/clock/reference confirmation','zero-drive and trip measurements',
                 'DC and independent complex transfer calibration','A/B standard verification and linearity/aliasing',
                 'ARM timing and physical HDMI/touch regression'],
        route_evidence='reports/be03_lowfreq_model_20261022/route_receipt.json')
    write(REPORTS/'acceptance.json',acceptance)
    files=[ROOT/'README.md']
    for folder in ('ps','rtl','sim','scripts','config','assets','docs','tests','models'):
        # Preserve historical BE01 repair helpers locally; do not ship them as BE03 build steps.
        files.extend(p for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts
                     and p.name not in ('finalize_timing.tcl','export_matching_xsa.tcl'))
    source={p.relative_to(ROOT).as_posix():sha(p) for p in sorted(files)}
    write(release/'source_manifest.json',source)
    archive=release/'battery_eis_rev_a_be03_20261022.zip'
    delivery=list(files)+[release/name for name in ('battery_eis.bit','battery_eis.hwh','battery_eis.xsa','manifest.json','source_manifest.json')]
    delivery.extend(p for p in REPORTS.rglob('*') if p.is_file() and p.suffix in ('.json','.rpt','.png','.csv','.txt','.md','.diff','.xdc','.tcl')
                    and 'host_simulation' not in p.parts)
    delivery.extend(p for p in (ROOT/'reports/ui').glob('*.png'))
    delivery.extend([ROOT/'reports/baseline_snapshot.txt',ROOT/'reports/historical_evidence.json',
                     REPORTS/'host_tests.log',simdir/'run.log',lowdir/'run.log'])
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for path in sorted(set(delivery)):z.write(path,'battery_eis_rev_a/'+path.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:raise ValueError('archive CRC failed')
    write(release/'archive_sha256.json',dict(file=archive.name,bytes=archive.stat().st_size,sha256=sha(archive)))
    print(json.dumps(dict(archive=str(archive),sha256=sha(archive),acceptance=acceptance),indent=2))

if __name__=='__main__':main()
