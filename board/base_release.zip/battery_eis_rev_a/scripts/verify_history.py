"""Recheck existing raw sweeps without rewriting any original evidence."""
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
WORKSPACE=ROOT.parent
LOGS=WORKSPACE/'reports/pynq_lockin'
sys.path.insert(0,str(WORKSPACE/'hardware/lockin/scripts'))
from validate_fixture_frequency_calibration import mean_responses,FREQUENCIES

def main():
    reports=[]
    for name in ('resistor_sweep_20260925.log','resistor_5k_sweep_20260926.log','resistor_5k_frozen_fresh_20260926.log'):
        path=LOGS/name;raw=path.read_bytes()
        rows=[json.loads(line) for line in raw.decode('utf-8-sig').splitlines() if line.startswith('{')]
        expected={(f,r,w) for f in FREQUENCIES for r in (1,2,3) for w in (1,2,3,4)}
        coordinates={(r['requested_frequency_hz'],r['round'],r['window']) for r in rows}
        assert len(rows)==252 and coordinates==expected
        assert raw.count(b'POINT_DONE ')==63 and b'PASS_PHASE_SWEEP' in raw
        assert b'EXCITATION_STOPPED_MIDSCALE control=0x0' in raw
        for row in rows:
            assert row['status']>>16==0x574a and row['status']&0x70==0
            assert row['amplitude']==4096 and abs(row['actual_frequency_hz']-row['requested_frequency_hz'])<.02
            counts=[row[ch]['count'] for ch in ('ad0','ad1')]
            assert all(13000<=n<=16000 for n in counts) and 28000<=sum(counts)<=30000
            assert all(math.isfinite(row[ch][k]) for ch in ('ad0','ad1') for k in ('i','q'))
        ratios=mean_responses(rows)
        reports.append(dict(file=str(path),sha256=hashlib.sha256(raw).hexdigest(),
            accepted_rows=len(rows),points_completed=raw.count(b'POINT_DONE '),
            frequency_hz=sorted(ratios),rounds=sorted({r['round'] for r in rows}),
            adc_counts=[min(r[ch]['count'] for r in rows for ch in ('ad0','ad1')),
                        max(r[ch]['count'] for r in rows for ch in ('ad0','ad1'))],
            pass_marker=b'PASS_PHASE_SWEEP' in raw,stop_marker=b'EXCITATION_STOPPED_MIDSCALE' in raw,
            run_exit_marker=b'RUN_EXIT=0' in raw,
            voltage_ratio_magnitude={str(f):abs(z) for f,z in sorted(ratios.items())}))
    spec=importlib.util.spec_from_file_location('frozen_recheck',LOGS/'evaluate_frozen_fixture_20260926.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    fresh=module.evaluate(LOGS/'resistor_5k_frozen_fresh_20260926.log')
    result=dict(raw_sweeps=reports,frozen_recheck=dict(coefficient_sha256=fresh['coefficient_sha256'],
        fresh_sha256=fresh['fresh_sha256'],summary=fresh['fresh_summary'],fitted_on_fresh_data=False),
        scope='Legacy large-signal RLC voltage-ratio data; no battery frontend, absolute impedance, new MUX timing, or mOhm accuracy claim')
    output=ROOT/'reports/historical_evidence.json'
    output.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(dict(rows=[r['accepted_rows'] for r in reports],frozen=fresh['fresh_summary']),indent=2))

if __name__=='__main__':main()
