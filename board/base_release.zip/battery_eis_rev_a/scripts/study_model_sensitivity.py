"""Input-perturbation study of frozen public-data research models.

No training or label-error evaluation is performed. The final exported models
were fitted using these public rows, so this is sensitivity on known inputs,
not held-out accuracy, new-cell generalisation, or target-board validation.
"""
import argparse
import copy
import csv
import hashlib
import json
import math
from pathlib import Path
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'ps'))
from model_bridge import HealthModel
from session import json_write


def cases():
    rows=[]
    for percent in (.1,.5,1.,2.):
        for sign in (-1,1):rows.append(('gain_%+g_pct'%(sign*percent),'gain',sign*percent/100))
    for degrees in (.1,.5,1.,2.):
        for sign in (-1,1):rows.append(('phase_%+g_deg'%(sign*degrees),'phase',math.radians(sign*degrees)))
    for milliohm in (.1,.5,1.):
        for sign in (-1,1):rows.append(('real_offset_%+g_mohm'%(sign*milliohm),'real',sign*milliohm/1000))
    return rows


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--research-root',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();args.output.mkdir(parents=True,exist_ok=False)
    reports={};hashes={}
    for dataset,name in [('lib','lib_two_ridge'),('kit','kit_two_forest')]:
        model_path=ROOT/'models/frozen_two_frequency_20261022'/(name+'.json')
        samples_path=args.research_root/(dataset+'_training_samples.csv')
        hashes[str(model_path)]=hashlib.sha256(model_path.read_bytes()).hexdigest()
        hashes[str(samples_path)]=hashlib.sha256(samples_path.read_bytes()).hexdigest()
        model=HealthModel(model_path)
        with samples_path.open(encoding='utf-8-sig',newline='') as stream:source=list(csv.DictReader(stream))
        baseline=[];rejected={}
        for row in source:
            sample=dict(source_domain=model.model['source_domain'],chemistry=model.model['chemistry'],
                soc_percent=float(row['soc']),temperature_C=model.model['measurement_temperature_C'][0],
                frequency_hz=list(model.model['frequencies_hz']),
                z_real_ohm=[float(row['re_low_ohm']),float(row['re_high_ohm'])],
                z_imag_ohm=[float(row['im_low_ohm']),float(row['im_high_ohm'])],
                impedance_unit='ohm',convention='passive_Z_re_plus_j_im',
                measurement_valid=True,calibration_valid=True)
            result=model.public_replay(sample)
            if result['status']=='research_estimate':
                baseline.append((row,sample,result['soh']))
            else:rejected[result['reason']]=rejected.get(result['reason'],0)+1
        summary=[]
        for label,kind,value in cases():
            deltas=[];reasons={};group_changes={};worst=None
            for row,sample,base in baseline:
                altered=copy.deepcopy(sample)
                zs=[complex(r,i) for r,i in zip(sample['z_real_ohm'],sample['z_imag_ohm'])]
                if kind=='gain':zs=[z*(1+value) for z in zs]
                elif kind=='phase':zs=[z*complex(math.cos(value),math.sin(value)) for z in zs]
                else:zs=[z+value for z in zs]
                altered['z_real_ohm']=[z.real for z in zs];altered['z_imag_ohm']=[z.imag for z in zs]
                out=model.public_replay(altered)
                if out['status']!='research_estimate':
                    reasons[out['reason']]=reasons.get(out['reason'],0)+1;continue
                delta=(out['soh']-base)*100;deltas.append(delta)
                group_changes.setdefault(row['group'],[]).append(abs(delta))
                if worst is None or abs(delta)>abs(worst['change_pp']):
                    worst=dict(row_id=row['row_id'],baseline_soh=base,perturbed_soh=out['soh'],change_pp=delta)
            values=np.array(deltas)
            summary.append(dict(case=label,baseline_accepted=len(baseline),perturbed_accepted=len(deltas),
                perturbed_rejected=len(baseline)-len(deltas),rejection_reasons=reasons,
                mean_abs_change_pp=float(np.abs(values).mean()) if len(values) else None,
                group_macro_mean_abs_change_pp=float(np.mean([np.mean(x) for x in group_changes.values()])) if group_changes else None,
                p95_abs_change_pp=float(np.quantile(np.abs(values),.95)) if len(values) else None,
                maximum_abs_change_pp=float(np.abs(values).max()) if len(values) else None,worst=worst))
        reports[dataset]=dict(model=name,total_known_rows=len(source),baseline_accepted=len(baseline),
            baseline_rejections=rejected,cases=summary)
        json_write(args.output/(dataset+'_sensitivity.json'),reports[dataset])
        print(json.dumps(dict(dataset=dataset,known_rows=len(source),baseline_accepted=len(baseline),cases=len(summary))),flush=True)
    json_write(args.output/'study.json',dict(schema='battery-model-sensitivity/1',source='public_training_inputs',
        pretrained_models_unchanged=True,new_training_performed=False,heldout_accuracy_evaluation=False,
        target_battery_validated=False,hardware_calibration_tolerance_established=False,
        input_sha256=hashes,studies=reports,
        assumptions=['Same complex gain or phase error at both frequencies',
            'Real offsets applied to both frequency inputs; no new battery observations',
            'Temperature gate uses dataset documented interval; no per-row temperature measurement inferred',
            'Changes are relative to each frozen model baseline, not measured SOH truth',
            'Rejected rows counted separately; delta percentiles use jointly accepted rows only'],
        interpretation='Use to prioritise amplitude/phase calibration and domain data collection; not a hardware accuracy claim.'))


if __name__=='__main__':main()
