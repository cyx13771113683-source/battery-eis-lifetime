"""Seeded, explicitly synthetic 1 mOhm step study for the final REV A values.

Each A/B estimate uses two independent captures, matching the default repeat
count. Gaussian noise is specified as ADC-input RMS per sample and is assumed
independent. Results are not a specification of the physical ADS1256/front end.
"""
import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
import argparse
import csv
from dataclasses import asdict
import json
from pathlib import Path
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'ps'))
sys.path.insert(0,str(ROOT/'scripts'))
from benchmark_ps import fixture
from configuration import Settings,DEFAULT_SWEEP
from synthetic import make_capture,sine_lut
from analysis import analyze,moments_from_raw
from session import json_write


def series_step(capture,settings,profile,resistance,lut):
    if resistance==0:return capture
    selected=capture.raw[:,3]==0
    phase=capture.raw[selected,1]*(2*np.pi/2**32)
    high=3.7/(profile.r_load_nominal_ohm+profile.r_shunt_ohm+.035+.04)
    current=np.full(len(phase),high/2)
    for harmonic in (1,3,5):
        current+=np.real(-1j*2*high/(np.pi*harmonic)*np.exp(1j*harmonic*phase))
    capture.raw[selected,2]-=np.rint(current*resistance/profile.voltage_divider/profile.code_volts).astype(np.int64)
    capture.moments=moments_from_raw(capture.raw,lut)
    return capture


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--trials',type=int,default=40,choices=range(2,51))
    args=p.parse_args();args.output.mkdir(parents=True,exist_ok=False)
    profile,_,_=fixture();lut=sine_lut();rows=[];summary=[]
    for frequency in DEFAULT_SWEEP:
        settings=Settings().for_frequency(frequency)
        for noise in (1e-6,10e-6,100e-6,500e-6):
            case=[]
            for trial in range(args.trials):
                zs=[];quality=[];voltages=[];currents=[]
                for step in (0,.001):
                    estimates=[]
                    for repeat in range(2):
                        sequence=1+trial*4+(2 if step else 0)+repeat
                        cap=series_step(make_capture(settings,profile,sequence,noise_v=noise),settings,profile,step,lut)
                        result=analyze(cap,settings,profile)
                        estimates.append(complex(*result['impedance_ohm']))
                        quality.append(result['quality_ok'])
                        if step==0:
                            currents.append(abs(complex(*result['current_ac_a'])))
                            voltages.append(abs(complex(*result['voltage_ac_v'])))
                    zs.append(sum(estimates)/2)
                delta=zs[1]-zs[0]
                row=dict(nominal_hz=frequency,actual_hz=settings.actual_frequency_hz,
                    adc_noise_rms_uv=noise*1e6,trial=trial,delta_real_mohm=delta.real*1000,
                    delta_imag_mohm=delta.imag*1000,error_mohm=abs(delta-.001)*1000,
                    all_four_quality_ok=all(quality),current_peak_a=float(np.mean(currents)))
                rows.append(row);case.append(row)
            errors=np.array([r['error_mohm'] for r in case]);real=np.array([r['delta_real_mohm'] for r in case])
            summary.append(dict(nominal_hz=frequency,adc_noise_rms_uv=noise*1e6,trials=len(case),
                accepted_trials=sum(r['all_four_quality_ok'] for r in case),
                mean_delta_real_mohm=float(real.mean()),std_delta_real_mohm=float(real.std(ddof=1)),
                error95_mohm=float(np.quantile(errors,.95)),max_error_mohm=float(errors.max()),
                fraction_error_under_0p1mohm=float(np.mean(errors<.1)),
                note='All trials included in error statistics, including quality-rejected trials'))
            print(json.dumps(summary[-1]),flush=True)
    with (args.output/'trials.csv').open('x',newline='',encoding='utf-8') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    high=3.7/(10+.1+.035+.04);fundamental=2*high/np.pi
    json_write(args.output/'summary.json',dict(source='synthetic_independent_gaussian_noise',
        physical_accuracy_validated=False,step_ohm=.001,repeats_per_side=2,
        dc_port_voltage_v=3.7,assumed_load_high_a=high,fundamental_current_peak_a=fundamental,
        predicted_1mohm_adc_step_peak_uv=fundamental*.001/1.249*1e6,
        per_channel_sample_rate_hz=1e8/(2*32768),cases=summary,
        assumptions=['Existing synthetic R0=10mOhm,Rp=30mOhm,tau=10ms port model',
            'Stationary DC and only first/third/fifth square-wave harmonics',
            'Series resistance step evaluated at unchanged current waveform',
            'Independent Gaussian noise at each ADC sample; no measured noise spectrum',
            'No converter filter, analog pickup, drift, contact changes or calibration error'],
        interpretation='Algorithm sensitivity study only; physical 1mOhm capability requires independent A/B standards and measured noise.'))


if __name__=='__main__':main()
