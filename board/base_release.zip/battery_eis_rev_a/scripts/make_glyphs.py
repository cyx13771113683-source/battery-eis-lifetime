"""Host-only rasterization of Noto Sans SC Medium at approved 20/24/32px."""
import sys
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'ps'))
from panel import LABELS
font_path=Path(sys.argv[1] if len(sys.argv)>1 else 'C:/Windows/Fonts/NotoSansSC-VF.ttf')
chars=sorted(set(LABELS+''.join(chr(i) for i in range(32,127))+''.join(c for c in (ROOT/'ps/panel.py').read_text(encoding='utf-8') if '\u4e00'<=c<='\u9fff')))
atlas={}
for size in (20,24,32):
    font=ImageFont.truetype(str(font_path),size)
    font.set_variation_by_axes([500])
    for char in chars:
        width=max(1,round(font.getlength(char)))
        im=Image.new('L',(width,size+8))
        ImageDraw.Draw(im).text((0,0),char,font=font,fill=255,anchor='lt')
        atlas['%d_%d'%(size,ord(char))]=np.array(im)
np.savez_compressed(ROOT/'assets/glyphs.npz',**atlas)
print('GLYPHS',len(chars),'sizes=20,24,32 weight=500')
