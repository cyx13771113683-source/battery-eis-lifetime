param([string]$Vivado='D:\software\vivado2025.2\2025.2\Vivado\bin\vivado.bat',[string]$Output='', [string]$WorkspaceAlias='D:\cyx\nt\be_ws_01a15e42')
$ErrorActionPreference='Stop'
$base=Split-Path $PSScriptRoot
$workspace=Split-Path $base
if(!$Output){$Output=Join-Path 'D:\cyx\nt' ('battery_eis_'+(Get-Date -Format 'yyyyMMdd-HHmmss'))}
if(!(Test-Path -LiteralPath $WorkspaceAlias)){throw 'Create a task-local short junction to the workspace; see README'}
$source=Join-Path $WorkspaceAlias 'vivado/2025.2/output/waveshare_five_electrode_20260921c/project/waveshare_five_electrode.xpr'
Push-Location (Join-Path $base 'build')
try {
 & $Vivado -mode batch -source "$PSScriptRoot/build.tcl" -log "$base/build/build.log" -journal "$base/build/build.jou" -tclargs $source $base $Output
 if($LASTEXITCODE){throw 'Vivado build failed; see build/build.log'}
 $reportDirectory=Join-Path $base 'reports/be03_lowfreq_model_20261022'
 New-Item -ItemType Directory -Path $reportDirectory -Force | Out-Null
 $Output | Set-Content -Encoding UTF8 (Join-Path $reportDirectory 'latest_build.txt')
} finally {Pop-Location}
