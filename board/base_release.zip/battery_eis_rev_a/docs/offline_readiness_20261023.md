# 到板前离线交付说明

2026-10-23。用户要求忽略额度停止条件，把测量PCB到货前可完成部分收尾。继续使用最终装配R1=10Ω/5W、R2=0.100Ω、R5=2.49kΩ和BE03位流；默认实际频率2.165324986/17.811544240Hz，各两次，窗口预算11.21283996秒。现有采集、估计器、模型权重及UI保持补丁B的运行逻辑。

## 离线验收范围

| 项目 | 离线完成证据 | 到板后工作 |
|---|---|---|
| PL/转换器协议 | 已有BE03完整构建、RTL故障仿真、SPI时序及故意缩短等待的负例 | 实际时钟、电平、DRDY、关断电流 |
| PS工作流 | 全部主机回归；双频模拟、取消、超时、故障、最终保存 | ARM整流程含初始化/RAM读取/HDMI计时 |
| 校准 | 精确binding、完整系数快照、空参考拒绝、覆盖检查 | 独立DC及每频点复数参考、实际R2 |
| 数据 | 原始CSV与全部18项累积复算、摘要、篡改拒绝 | 真实物理来源、接线、温度/SOC和标准件证据 |
| 模型 | 冻结公开样本回放、单位/频点/来源/SOC/温度拒判、无伪造容量标签 | 目标电芯容量配对、独立留芯验证 |
| 界面 | 沿用44画面逐像素等价证据，主机显示与状态测试 | 真HDMI、触摸拔插和取消 |
| 暂态候选 | 只读诊断、相同记录对比、合成压力集 | 新估计器独立校准和实际收益/成本 |

上述离线完成不意味着实物阻抗精度或寿命预测已经验收。

## 一键运行

在解压后的`battery_eis_rev_a`目录执行，输出目录必须不存在：

```powershell
python -B scripts/accept_offline.py --output reports/my_offline_acceptance
```

依赖现有Python、NumPy和Pillow；不新增第三方依赖。测试采用临时目录。模拟、复算、诊断、模板等子流程安装导入守卫，拒绝PYNQ/SPI/GPIO库；入口不会调用measure/panel、联网或修改板卡。

完成后查看`acceptance.json`和逐步骤日志。`status=PASS`只表示本表离线软件范围。`failure.json`表示验收中途失败，应按日志修复并在新目录重跑；不得把部分日志当成通过。

`arrival_kit`包括：

- `profile.pending.json`：所有实物确认项仍为false，序列号及哈希待填。
- `metadata.pending.json`：温度、SOC和老化组保持null；必须真实记录。
- `reference.pending.json`：待独立参考填表，不能转为有效校准。
- `capacity_pairing.pending.json`：独立容量与EIS配对记录，初始容量和当前容量均不预填。
- `acceptance.pending.json`：13项实物检查保留null。

先完成真实profile，再重新运行calibration-template生成与其binding匹配的参考表。不能只把确认项改为true而跳过测量。容量标签定义须注明Q/Q0或Q/额定容量，按电芯和共同老化组隔离训练/测试；模型预测不充当容量标签。模拟目录及故意损坏的负例目录不得加入实测训练集。

## 保存数据后的诊断

```powershell
python -B ps/app.py audit-session --session data/实际会话 --output reports/audit.json
python -B scripts/diagnose_session.py --session data/实际会话 --output reports/diagnostic.json
python -B ps/app.py export-candidate --session data/实际会话 --output reports/candidate.json
```

旧会话缺少完整校准快照时，三个命令均可额外指定原始`--calibration`文件。输出不得写入原会话；原始数据和原有判定保留。

诊断先做原始数据复算，再比较PL估计与带线性趋势、3/5次谐波和工频干扰项的时间戳拟合。两者差异只能用于排查，不能当作准确度或自动修正值。诊断结果始终`diagnostic_valid_for_measurement=false`、`model_evaluation_allowed=false`，不会生成新的有效SOH。若今后切换生产估计器，必须更新binding并重新校准。

## 暂态研究的结论

既有24个理想电路案例发现，慢极化时重复性良好仍可能保留约2.27%的低频均值偏差。趋势拟合能改善部分案例，但无法消除同频耦合，也并非每例更好。

本轮固定已有两个估计器，在24组新随机Randles参数、双频、两种初始状态、白噪声/AR(1)/同频干扰及两次重复下生成576窗；另加入3%整对漏采和时间抖动。288组配对全部计入误差统计，未筛掉被原质量门限拒绝的案例。详细参数、试验与局限见`reports/offline_ready_20261023_a/stress_transient/`。

该压力集是软件研究，不是新电池盲测。它支持把趋势拟合保留为诊断候选，暂不替换已冻结生产算法；更复杂算法不能代替独立参考、相位校准和同频串扰排查。

## 到板后的唯一入口

按`board_acceptance.md`逐项验收。先装配/无源连通、电源电平、零驱动与保护，再DC/复数传递校准、标准A/B、暂态/线性/噪声和完整ARM计时。旧RLC连接时不加载电池程序；需要联网时遵守保留正常上网规则。本交付不自动部署、写启动配置或接通负载。
